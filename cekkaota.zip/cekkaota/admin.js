document.addEventListener("DOMContentLoaded", () => {
    alert("Admin Panel Siap Digunakan");
});