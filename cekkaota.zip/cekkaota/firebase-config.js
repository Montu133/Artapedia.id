const firebaseConfig = {
    apiKey: "AIzaSyC1tHRueP_Yhh8bxgglvWnBOlP9QG0qWqg",
    authDomain: "arta-57b45.firebaseapp.com",
    projectId: "arta-57b45",
    storageBucket: "arta-57b45.firebasestorage.app",
    messagingSenderId: "592271829041",
    appId: "1:592271829041:web:f4f9ed4b21905e50d1cd10",
    measurementId: "G-XY1DRLS38C"
};
firebase.initializeApp(firebaseConfig);